To include the definitions of the module's classes, use the following directive:

::

    import PySide6.QtMultimedia


