To include the definitions of modules classes, use the following directive:

::

    import PySide6.QtGui

.. seealso:: :mod:`PySide6.QtCore`
