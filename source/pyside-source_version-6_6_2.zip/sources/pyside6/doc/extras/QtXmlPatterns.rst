To include the definitions of the module's classes, use the following directive:

::

    import PySide6.QtXmlPatterns

Further Reading
---------------

General overviews of XQuery and XSchema can be found in the XQuery document.

An introduction to the XQuery language can be found in A Short Path to XQuery.
