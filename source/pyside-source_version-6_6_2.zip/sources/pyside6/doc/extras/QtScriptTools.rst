Applications that use the Qt Script Tools classes need to be configured to be built against the QtScriptTools module. To include the definitions of the module's classes, use the following directive:

::

    import PySide6.QtScriptTools
