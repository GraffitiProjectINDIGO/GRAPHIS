All other Qt modules rely on this module. To include the definitions of the module's classes, use the following directive:

::

    import PySide6.QtCore
