Any qdoc source files in this directory will be parsed when generating docs.
