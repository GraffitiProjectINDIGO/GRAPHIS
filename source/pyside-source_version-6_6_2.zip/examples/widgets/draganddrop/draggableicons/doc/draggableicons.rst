Draggable Icons Example
=======================

The Draggable Icons example shows how to drag and drop image data between
widgets in the same application,and between different applications.

.. image:: draggableicons.png
   :width: 536
   :alt: draggable icons screenshot
