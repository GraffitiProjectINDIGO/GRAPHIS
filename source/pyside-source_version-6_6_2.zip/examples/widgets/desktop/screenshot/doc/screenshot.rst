Screenshot Example
==================

The Screenshot example shows how to take a screenshot of the desktop.

.. image:: screenshot.png
   :width: 373
   :alt: Screenshot program screenshot
