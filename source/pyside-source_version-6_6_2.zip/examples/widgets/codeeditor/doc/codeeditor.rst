Code Editor Example
===================

The Code Editor example shows how to create a simple editor that has line
numbers and that highlights the current line.

.. image:: painter.png
   :width: 400
   :alt: Code Editor Screenshot
