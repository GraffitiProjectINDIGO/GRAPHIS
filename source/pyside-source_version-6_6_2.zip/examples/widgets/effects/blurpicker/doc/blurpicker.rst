Blur Picker Effect Example
==========================

The blur picker effect example demonstrates how to apply
graphical effects on items in the view.

.. image:: blurpicker.png
   :width: 400
   :alt: Blur Picker Screenshot
