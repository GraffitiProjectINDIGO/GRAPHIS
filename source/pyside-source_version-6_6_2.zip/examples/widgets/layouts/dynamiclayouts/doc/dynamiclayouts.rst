Dynamic Layouts Example
=======================

Dynamic Layouts implements dynamically placed widgets within running
applications. The widget placement depends on whether Horizontal or Vertical is
chosen.

.. image:: basiclayouts.png
   :width: 400
   :alt: Dynamic Layouts Screenshot
