Basic Layouts Example
=====================

Basic Layouts shows how to use the standard layout managers that are available
in Qt Widgets: QBoxLayout, QGridLayout, and QFormLayout.

.. image:: basiclayouts.png
   :width: 400
   :alt: Basic Layouts Screenshot
