Dock Widget Example
===================

The Dock Widgets example shows how to add dock windows to an application. It
also shows how to use Qt's rich text engine.

.. image:: dockwidgets.png
   :width: 400
   :alt: Dock Widgets Screenshot
