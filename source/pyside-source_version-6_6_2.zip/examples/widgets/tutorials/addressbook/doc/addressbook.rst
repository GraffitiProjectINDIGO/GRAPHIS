Address Book Example
====================

The address book example shows how to use proxy models to display different
views onto data from a single model.

.. image:: addressbook.png
   :width: 400
   :alt: Address Book Screenshot
