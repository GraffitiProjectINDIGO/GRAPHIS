Cannon Example
==============

Simple Cannon example.

.. image:: cannon.png
   :width: 400
   :alt: Cannon Screenshot
