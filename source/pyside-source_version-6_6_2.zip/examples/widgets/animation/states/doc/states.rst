States Example
==============

The States example shows how to use the Qt state machine to play animations.

.. image:: states.png
   :width: 400
   :alt: States Screenshot
