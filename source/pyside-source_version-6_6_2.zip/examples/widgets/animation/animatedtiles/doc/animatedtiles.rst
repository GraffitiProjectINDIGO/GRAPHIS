Animated Tiles Example
======================

The Animated Tiles example animates items in a graphics scene.

.. image:: animatedtiles.png
   :width: 400
   :alt: Animated Tiles Screenshot
