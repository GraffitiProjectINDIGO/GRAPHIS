Easing Example
==============

The Easing Curves example shows how to use easing curves to control the speed
of an animation.

.. image:: easing.png
   :width: 400
   :alt: Easing Screenshot
