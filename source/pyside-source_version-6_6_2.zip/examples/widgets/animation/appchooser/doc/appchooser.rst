Application Chooser Example
===========================

Simple application that shows the effect of selecting an
application from the corners of the widget.

.. image:: appchooser.png
   :width: 400
   :alt: Application Chooser Screenshot
