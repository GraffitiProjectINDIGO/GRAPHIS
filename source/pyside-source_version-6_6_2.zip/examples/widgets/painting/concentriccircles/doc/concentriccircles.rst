Concentric Circles Examples
===========================

Demonstrates the improved quality that antialiasing and floating point
precision gives.

The application's main window displays several widgets which are drawn using
the various combinations of precision and anti-aliasing.

.. image:: concentriccircles.png
   :width: 400
   :alt: Concentric Circles Screenshot
