Painter Example
===============

Simple painter application based on Qt Widgets.

.. image:: painter.png
   :width: 400
   :alt: Painter Screenshot
