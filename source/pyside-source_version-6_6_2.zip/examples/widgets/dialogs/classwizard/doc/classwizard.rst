Classwizard Example
===================

Demonstrates the use of QDialog in a wizard application

This example demonstrates the use a custom QDialog in a wizard,
which generates Python class template code.

.. image:: classwizard.png
   :width: 400
   :alt: classwizard screenshot
