JSON Model Example
==================

Simple example to visualize the values of a JSON file.

.. image:: jsonmodel.png
   :width: 400
   :alt: JSON Model Screenshot
