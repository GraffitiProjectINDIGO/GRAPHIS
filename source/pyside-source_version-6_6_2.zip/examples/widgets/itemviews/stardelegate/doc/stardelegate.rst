Star Delegate Example
=====================

Demonstrates Qt's itemview architecture

This example demonstrates the Qt model view architecture.

.. image:: stardelegate.png
   :width: 400
   :alt: Star Delegate Screenshot
