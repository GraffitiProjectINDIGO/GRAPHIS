TextEdit Example
================

The Text Edit example shows Qt's rich text editing facilities in action.

.. image:: textedit.png
   :width: 400
   :alt: TextEdit Screenshot
