Syntax Highlighter Example
==========================

The Syntax Highlighter example shows how to perform simple syntax highlighting.

.. image:: syntaxhighlighter.png
   :width: 400
   :alt: Syntax Highlighter Screenshot
