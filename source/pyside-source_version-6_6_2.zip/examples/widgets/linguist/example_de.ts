<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE" sourcelanguage="de_DE">
<context>
    <name>Window</name>
    <message>
        <location filename="main.py" line="56"/>
        <source>&amp;File</source>
        <translation>&amp;Datei</translation>
    </message>
    <message>
        <location filename="main.py" line="57"/>
        <source>Quit</source>
        <translation>Beenden</translation>
    </message>
    <message>
        <location filename="main.py" line="58"/>
        <source>CTRL+Q</source>
        <translation>CTRL+B</translation>
    </message>
    <message>
        <location filename="main.py" line="60"/>
        <source>&amp;Help</source>
        <translation>Hilfe</translation>
    </message>
    <message>
        <location filename="main.py" line="61"/>
        <source>About Qt</source>
        <translation>Über Qt</translation>
    </message>
    <message numerus="yes">
        <location filename="main.py" line="75"/>
        <source>%n language(s) selected</source>
        <translation>
            <numerusform>Eine Sprache ausgewählt</numerusform>
            <numerusform>%n Sprachen ausgewählt</numerusform>
        </translation>
    </message>
</context>
</TS>
