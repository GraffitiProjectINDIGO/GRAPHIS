Matplotlib Widget Gaussian Example
==================================

A Python application that demonstrates how to interact with
matplotlib and scipy, combined with Qt Widgets.

.. image:: widget_gaussian.png
   :width: 400
   :alt: Matplotlib Widget Gaussian Screenshot
