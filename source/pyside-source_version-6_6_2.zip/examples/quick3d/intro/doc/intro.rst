Introduction Example Qt Quick 3D
================================

This example gives an introductory overview of the basic Quick 3D features by going
through the code of a simple example.

.. image:: intro.png
   :width: 400
   :alt: QtQuick3D Introduction Screenshot
