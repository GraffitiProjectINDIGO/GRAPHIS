Simple Qt 3D Example
====================

A Python application that demonstrates how to render a scene in Qt 3D.

.. image:: simple3d.png
   :width: 400
   :alt: Simple 3D Screenshot
