WebChannel Standalone Example
=============================

A simple chat between a server and a remote client running in a browser.

.. image:: standalone.png
   :width: 400
   :alt: WebChannel Standalone Screenshot
