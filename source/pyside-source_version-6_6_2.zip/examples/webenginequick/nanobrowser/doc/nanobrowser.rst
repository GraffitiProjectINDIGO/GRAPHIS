Nano Browser Example
====================

A web browser implemented using the WebEngineView QML type.

.. image:: nanobrowser.png
   :width: 400
   :alt: Nano Browser Screenshot
