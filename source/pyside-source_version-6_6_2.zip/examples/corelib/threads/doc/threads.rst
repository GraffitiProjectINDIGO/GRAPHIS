Mandelbrot Threads Example
==========================

The Mandelbrot example demonstrates multi-thread programming using Qt. It shows
how to use a worker thread to perform heavy computations without blocking the
main thread's event loop.

.. image:: threads.png
   :width: 400
   :alt: Mandelbrot Threads Screenshot
