QAbstractListModel in QML
=========================

This example shows how to add, remove and move items inside a QML
ListView, but showing and editing the data via roles using  a
QAbstractListModel from Python.

You can add new elements and reset the view using the two top buttons,
remove elements by 'middle click' the element, and move the elements
with a 'left click' plus dragging the item around.

.. image:: qabstractlistmodelqml.png
   :width: 400
   :alt: QAbstractListModel/ListView Screenshot
