Simple Browser Example
======================

A simple browser based on Qt WebEngine Widgets.

.. image:: simplebrowser.png
   :width: 400
   :alt: Simple Browser Screenshot
