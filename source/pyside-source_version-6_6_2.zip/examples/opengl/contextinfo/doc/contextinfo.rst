Context Info Example
====================

The example shows the information about the OpenGL-related graphics
configuration of the current system. This can be useful as a
diagnostic tool.

.. image:: contextinfo.png
   :width: 400
   :alt: Context Simple Screenshot
