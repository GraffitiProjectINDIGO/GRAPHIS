Hello GL2 Example
=================

The Hello GL2 example demonstrates the basic use of the OpenGL-related classes
provided with Qt.

.. image:: hellogl2.png
   :width: 400
   :alt: Hello GL2 Screenshot
