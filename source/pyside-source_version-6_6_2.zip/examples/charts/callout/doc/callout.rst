Callout Example
===============

This example shows how to draw an additional element (a callout) on top of the chart.

.. image:: callout.png
   :width: 400
   :alt: Callout Screenshot
