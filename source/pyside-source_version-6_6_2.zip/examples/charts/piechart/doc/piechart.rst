Pie Chart Example
=================

The example shows how to create a simple pie chart and do some customizations to a pie slice.

.. image:: piechart.png
   :width: 400
   :alt: Pie Chart Screenshot
