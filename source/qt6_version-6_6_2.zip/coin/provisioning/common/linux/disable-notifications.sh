#!/usr/bin/env bash

gsettings set org.gnome.desktop.notifications.application:/update-manager/ enable false
gsettings set org.gnome.desktop.notifications show-banners false
