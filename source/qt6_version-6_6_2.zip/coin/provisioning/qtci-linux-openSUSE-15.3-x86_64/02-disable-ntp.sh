#!/usr/bin/env bash
# shellcheck source=../common/linux/disable-ntp_linux.sh
source "${BASH_SOURCE%/*}/../common/linux/disable-ntp_linux.sh"
