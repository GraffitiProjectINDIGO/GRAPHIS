#!/bin/sh

"$(dirname "$0")"/../common/unix/telegraf_install.sh
