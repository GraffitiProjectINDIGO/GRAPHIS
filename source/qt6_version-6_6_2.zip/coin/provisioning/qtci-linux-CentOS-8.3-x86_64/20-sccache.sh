#!/usr/bin/env bash

source "${BASH_SOURCE%/*}/../common/linux/sccache.sh"
