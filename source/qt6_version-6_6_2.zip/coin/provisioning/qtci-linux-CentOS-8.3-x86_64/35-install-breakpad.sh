#!/usr/bin/env bash

set -ex

# shellcheck source=../common/unix/install-breakpad.sh
source "${BASH_SOURCE%/*}/../common/unix/install-breakpad.sh"
