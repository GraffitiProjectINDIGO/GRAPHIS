#!/bin/bash

BASEDIR=$(dirname "$0")
"$BASEDIR/../common/linux/ubuntu-version.sh"
