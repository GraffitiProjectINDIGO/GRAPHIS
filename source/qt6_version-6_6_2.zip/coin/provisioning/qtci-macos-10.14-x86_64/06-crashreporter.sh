#!/usr/bin/env sh

set -ex

defaults write com.apple.CrashReporter DialogType server
