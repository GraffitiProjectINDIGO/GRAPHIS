#!/usr/bin/env bash

set -ex

brew install pcre2
