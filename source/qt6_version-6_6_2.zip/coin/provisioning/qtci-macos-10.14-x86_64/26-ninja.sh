#!/usr/bin/env bash

set -ex

# shellcheck source=../common/macos/ninja.sh
source "${BASH_SOURCE%/*}/../common/macos/ninja.sh"


