#!/usr/bin/env bash

set -e

BASEDIR=$(dirname "$0")
"$BASEDIR/../common/macos/homebrew.sh"
