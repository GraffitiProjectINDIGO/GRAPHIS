#!/usr/bin/env bash

source "${BASH_SOURCE%/*}/../common/macos/sccache.sh"
