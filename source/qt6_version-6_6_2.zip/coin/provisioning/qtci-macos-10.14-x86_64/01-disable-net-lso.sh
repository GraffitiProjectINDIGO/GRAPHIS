#!/bin/sh

"$(dirname "$0")"/../common/macos/disable_net_lso.sh
