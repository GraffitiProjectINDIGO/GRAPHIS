#!/bin/sh

"$(dirname "$0")"/../common/macos/telegraf_install.sh
